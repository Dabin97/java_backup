
public class Test1 {
// 알파벳 대소문자를 A ~ Z, a ~ z 를 순서대로 출력하세요
	public static void main(String[] args) {
		 
		for(int i = 65; i<=122; i++) {
			int t1=0,t2=0;
			if(i>96 && i<123) { //소
				t1 = i;
			}
			if(i>64 && i<91) { //대
				t2 = i;
			}
			System.out.println((char)t2 + "-" +(char)t1);
		}
		
		
		}//main
		
	}
//	A = 65 Z-90
//	a = 97 z-122

