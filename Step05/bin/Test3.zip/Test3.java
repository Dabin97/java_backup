import java.util.Scanner;

public class Test3 {
//숫자 두개를 입력 받은 후 두 숫자의 최대 공약수를 출력하시오.
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("숫자 입력 : ");
		int n1 = sc.nextInt();
		System.out.print("숫자 입력 : ");
		int n2 = sc.nextInt();
		int min =0, max=0;
		int temp = 0;
		
		for(int i = 1; i <= n1; i++) {
			if(n1%i==0 && n2%i==0) {
				temp = i;
				if(temp < i) 
					max = temp;
				if(temp > i)
					min = temp;
			}//if
		} //for
		System.out.print(temp);
		
		 
		
		
		
		
	}//main

}
